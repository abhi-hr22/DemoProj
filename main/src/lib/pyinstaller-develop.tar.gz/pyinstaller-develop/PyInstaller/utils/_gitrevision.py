#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "55c8855d9d"     # abbreviated commit hash
commit = "55c8855d9db0fa596ceb28505f3ee2f402ecd4da"  # commit hash
date = "2020-01-19 23:22:35 +0100"   # commit date
author = "FeralRobot <38778116+FeralRobot@users.noreply.github.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """doc: Fix code example for "are we bundled?" check

The "are we bundled?" check code did run when frozen, but not if not frozen.
Obviously, the code should run in both configurations."""
